package test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class FileLoader {

	private String path;
	private String[] fileList;
	private BufferedImage[] imageList;
	private ImageIcon[] icon;
	
	private int size = 100;
	private File folder;
	private int fileCount;
	
	private BufferedImage folderImage;
	private BufferedImage rawImage;

	public FileLoader(String path) {
		imageList = new BufferedImage[size];
		fileList = new String[size];
		icon = new ImageIcon[size];

		this.path = path;
		
		try {
			folderImage = ImageIO.read(new File("res/folder.png"));
			rawImage = ImageIO.read(new File("res/raw.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*
	 * path ���� ó������� ��. 1. ���丮�� ��� 2. ������ ��� 3. �߸��� ����� ��� 4. ��Ʈ�� �ִ��� ������
	 */

	public void LoadFiles(File folder) {
		folder = this.folder;
		imageList = new BufferedImage[size];

		int i = 0;
		this.path = folder.getAbsolutePath();
		
		fileCount = 0;
		for (File fileEntry : folder.listFiles()) {
			this.fileCount++;
			if (fileEntry.isDirectory()) {
				fileList[i] = fileEntry.getAbsolutePath();
				imageList[i++] = folderImage;
				
			} else {
				fileList[i] = fileEntry.getName();
				int pos = fileList[i].lastIndexOf('.');
				if ( fileList[i].substring(pos+1) == "raw" || fileList[i].substring(pos+1) == "RAW" ) {
					imageList[i++] = rawImage;
				}else {
					try {
						imageList[i++] = ImageIO.read(fileEntry);
					} catch (IOException e) {
					}
				}
			}
		}

	}

	public void LoadFiles() {
		imageList = new BufferedImage[size];

		folder = new File(path);

		if (!folder.exists()) { // ���丮 ������ ����.
			folder.mkdirs();
		}

		int i = 0;
		fileCount = 0;
		for (File fileEntry : folder.listFiles()) {
			this.fileCount++;
			if (fileEntry.isDirectory()) {
				//fileList[i] = fileEntry.getAbsolutePath();
				fileList[i] = fileEntry.getName();
				imageList[i++] = folderImage;
				
			} else {
				
				//fileList[i] = fileEntry.getAbsolutePath();
				fileList[i] = fileEntry.getName();
				int pos = fileList[i].lastIndexOf('.');
				if ( fileList[i].substring(pos+1).equals("raw") || fileList[i].substring(pos+1).equals("RAW") ) {
					imageList[i++] = rawImage;
				}else {
					try {
						imageList[i++] = ImageIO.read(fileEntry);
					} catch (IOException e) {
					}
				}
				
			}
		}

	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String[] getFileList() {
		return fileList;
	}

	public BufferedImage[] getImageList() {
		return imageList;
	}

	public ImageIcon[] getIcon() {
		return icon;
	}
	
	public File getFolder() {
		return this.folder;
	}
	
	public int getFileCount() {
		return fileCount;
	}
}
