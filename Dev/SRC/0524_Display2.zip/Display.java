package framework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import database.DB_insert;

/*
 * setPath�� ����, path ������Ʈ�� �ʿ��ϴ�.
 * */

public class Display extends JFrame{

	private JPanel panel;
	private JPanel canvas;
	private JTextField field;
	
	public String path;
	private int width, height;
	
	//
	ListPanel listpan;
	ButtonPanel btnpan;
	static Vector<CustomerInfo> c_vec;
	private GridBagConstraints gbc_panel_1;

	Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	public Display() {
		this.width = res.width;
		this.height = res.height;
		path = "C:/";
		init();
		//default path
		
	}
	
	public Display(String path) {
		this.width = res.width;
		this.height = res.height;
		this.path = path;
		
		init();
	}
	
	public void init() {
		this.setTitle("title");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		GridBagConstraints gbc_panel = new GridBagConstraints();
		c_vec=new Vector(1);
		setSize(1000,800);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{294, 436, 84, 0};
		gridBagLayout.rowHeights = new int[]{472, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 1.0, 0.0};
		gridBagLayout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		listpan= new ListPanel(this);
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 0;
		getContentPane().add(listpan, gbc_panel);
		
		btnpan=new ButtonPanel(c_vec,listpan);
		gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 3;
		gbc_panel.gridy = 0;
		getContentPane().add(btnpan, gbc_panel);
		
		panel = new JPanel();
		gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 2;
		gbc_panel_1.insets = new Insets(0, 0, 0, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 0;
		getContentPane().add(panel, gbc_panel_1);
		canvas = new JPanel();
		canvas.setLayout(new FlowLayout(FlowLayout.LEFT,10,10));
		field = new JTextField();
		
		panel.setSize(512, 512);
		panel.setBorder(BorderFactory.createLineBorder(Color.black));
		panel.setLayout(new BorderLayout());
		
		field.setSize(100, 100);
		field.setText(path);
		field.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				path = field.getText();
				System.out.println(path);
			}
		});
		
		panel.add(canvas, "Center");
		panel.add(field, "North");
		
		
		setVisible(true);
		
		DB_insert dbi =new DB_insert();
		c_vec.removeAllElements();
		try {
			dbi.getRecord(c_vec);
		}
		catch(SQLException se) {
			System.out.println(se);
		}
		listpan.setList(c_vec);
	}
	
	public JFrame getFrame() {		//�߰�
		return this;
	}
	public JPanel getPanel() {
		return panel;
	}

	public JPanel getCanvas() {
		return canvas;
	}

	public JTextField getField() {
		return field;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getPath() {
		return path;
	}

	public String getFieldString() { //
		return field.getText();
	}
	
	public void setPath(String path) {
		this.path = path;
	}
	
	public void render(ImageIcon[] icon, String[] filePath, 
			String[] fileName, int count) {
		 
		for ( int i = 0 ; i < count ; i++ ) {
			JLabel label = new JLabel();
			// ������
			label.setIcon(icon[i]);
			label.setPreferredSize(new Dimension(90,90));
			
			// ���� ���̺�
			JLabel colorLabel = new JLabel(" ");
			colorLabel.setOpaque(true);
			colorLabel.setPreferredSize(new Dimension(20,20));
			colorLabel.setBackground(Color.white);
			
			// ���� �˾�
			JPopupMenu colorPopup = new JPopupMenu();
        	//�޴�������		
        	JMenuItem white = new JMenuItem("white");
        	JMenuItem black = new JMenuItem("black");
        	JMenuItem red = new JMenuItem("red");
        	JMenuItem green = new JMenuItem("green");
        	JMenuItem blue = new JMenuItem("blue");
        	
        	colorPopup.add(white);
        	colorPopup.add(black);
        	colorPopup.add(red);
        	colorPopup.add(green);
        	colorPopup.add(blue);
        	
        	class ActionClass implements ActionListener
        	{
        		@Override
        		public void actionPerformed(ActionEvent e) {
        			String obj = e.getActionCommand();
        			System.out.println(obj);
        			switch( obj ) {
        			case "white": colorLabel.setBackground(Color.white); break;
        			case "black": colorLabel.setBackground(Color.black); break;
        			case "red"	: colorLabel.setBackground(Color.red);	 break;
        			case "green": colorLabel.setBackground(Color.green); break;
        			case "blue"	: colorLabel.setBackground(Color.blue);	 break;
        			}
        		}
        	}
        	// �̺�Ʈ ������
            white.addActionListener(new ActionClass());
            black.addActionListener(new ActionClass());
            red.addActionListener(new ActionClass());
            green.addActionListener(new ActionClass());
            blue.addActionListener(new ActionClass());

            colorLabel.add(colorPopup);
			colorLabel.addMouseListener(new MouseAdapter(){
				//���콺 Ŭ��
			    public void mousePressed(MouseEvent evnt) {
			    	// ��Ŭ����
			        if (evnt.getModifiers() == MouseEvent.BUTTON3_MASK) {
			        	//�˾�
			        	colorPopup.show(label, evnt.getX(), evnt.getY());
			        }
			     }
			});
			
			
			// �����̸�
			JLabel nameLabel = new JLabel(fileName[i]);
			nameLabel.setPreferredSize(new Dimension(70,20));
			
			// ���̺� �гο� ����
			JPanel iconPanel = new JPanel();
			iconPanel.setLayout(new BorderLayout());
			iconPanel.add(label, BorderLayout.CENTER);
			JPanel namePanel = new JPanel();
			namePanel.add(colorLabel);
			namePanel.add(nameLabel);
			iconPanel.add(namePanel, BorderLayout.SOUTH);
			
			//�˾�
			JPopupMenu popup = new JPopupMenu();
        	//�޴�������		
        	JMenuItem open = new JMenuItem("����");
        	JMenuItem delete = new JMenuItem("����");
        	JMenuItem open_photo = new JMenuItem("���伥���� ����");
        	JMenuItem edit = new JMenuItem("����");
        	JMenuItem add_memo = new JMenuItem("�޸�");
        	
        	popup.add(open);
        	popup.add(delete);
        	popup.add(open_photo);
        	popup.add(edit);
        	popup.add(add_memo);
 
        	class PopupActionClass implements ActionListener
        	{
        		@Override
        		public void actionPerformed(ActionEvent e) {
        			String obj = e.getActionCommand();
        			System.out.println(obj);
        			switch( obj ) {
        			
        			}
        		}
        	}
        	
        	// �̺�Ʈ ������
            open.addActionListener(new PopupActionClass());
        	delete.addActionListener(new PopupActionClass());
        	open_photo.addActionListener(new PopupActionClass());
        	edit.addActionListener(new PopupActionClass());
        	add_memo.addActionListener(new PopupActionClass());
        	
        	
        	String filepath = filePath[i];
        	label.add(popup);
			label.addMouseListener(new MouseAdapter(){
				//���콺 Ŭ��
			    public void mousePressed(MouseEvent evnt) {
			    	// ��Ŭ����
			        if (evnt.getModifiers() == MouseEvent.BUTTON3_MASK) {
			        	popup.show(label, evnt.getX(), evnt.getY());
			        }
			     }
			    //���콺 �ȿ� �޸� ����
			    public void mouseEntered(MouseEvent evnt ) {
			    	int pos = filepath.lastIndexOf('.');
			    	// ���͸��ϰ��
			    	if ( pos == -1 ) return;
			    	
				    File memofile = new File( filepath.substring(0,pos) + ".txt");
				    // �޸� �������
				    if ( memofile.exists() == false) return;
				    
				    StringBuffer memo_sb = new StringBuffer();
				    
				    try {
				        BufferedReader in = new BufferedReader(new FileReader(memofile));
				        String str;
				        // �ٹٲ����� html �±�����
				        memo_sb.append("<html>");
				        while ((str = in.readLine()) != null) {
				          memo_sb.append(str + "<br>");
				        }
				        memo_sb.append("</html>");
				        in.close();
				    } catch (IOException e) {
				          e.printStackTrace();
				    }
				    // ���� ����
			    	label.setToolTipText(memo_sb.toString());
			    }

			});
			canvas.add(iconPanel);
		}
		canvas.validate();
		canvas.repaint();
	}

	public void clean_render() {
		canvas.removeAll();
	}
}
