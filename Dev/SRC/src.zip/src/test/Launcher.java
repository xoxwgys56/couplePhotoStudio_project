package test;

public class Launcher {

	public static void main(String[] args) {
		new FrameWork().start();
		//new TableFrameWork("D:/testImg");
	}
}
