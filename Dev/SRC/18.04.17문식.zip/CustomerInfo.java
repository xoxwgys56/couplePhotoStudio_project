package BuBuPhotoshop;

import java.util.Date;

public class CustomerInfo {
	String name;
	String phoneNum;
	String photoType;
	int num;
	int numOfPeople=1;
	String creationDate;
	String reservationDate;
	String lastDate;
	String calibrationInfo;
	int charge;
}
