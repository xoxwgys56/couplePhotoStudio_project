package input;

import java.awt.Color;
import java.awt.Graphics;

public class PopUp {

	private boolean activated, focus;
	private int cursor_x, cursor_y;
	private int x, y;
	private int width, height;
	
	public PopUp() {
		this.activated = false;
		this.focus = false;
		width = 100;
		height = 200;
	}
	
	private void init() {
		activated = true;
	}
	
	private void reset() {
		activated = false;
	}
	
	public void tick(MouseManager mouse, int cursor_x, int cursor_y) {
		this.cursor_x = cursor_x;
		this.cursor_y = cursor_y;
		
		if (!activated && mouse.right_clicked) {
			init();
			x = cursor_x;
			y = cursor_y;
		}
		//else if (!activated reutnr
		
		if ( (x>=cursor_x && x<=cursor_x+width) && (y>=cursor_y && y<=cursor_y+height)) {
			this.focus = true;
		}else if (mouse.left_clicked || mouse.right_clicked) {
			reset();
		}else {
			this.focus = false;
		}
		
		
	}
	
	public void render(Graphics g) {
		if (!activated)
			return ;
		
		g.setColor(new Color(255, 0, 0));
		g.fillRect(x, y, width, height);
		
		if (focus) {
			g.setColor(new Color(0, 255, 0));
			g.fillRect(x, cursor_y, width, 50);
		}
	}
}
