package framework;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

public class Setup extends JFrame implements ActionListener{

      private JPanel expanel,setpanel;
      private JTextField textField;
      private JLabel label,label1;
      private JButton button1;
     // private FrameWork frame;
      private String changePath;
   
      private String previous;
      private database.DB_insert db;
      private Display display;
      
      public Setup() {
    	 //System.out.println("setUP"); ������� ������ �� Ȯ��
        setSize(400,100);
        BoxLayout layout = new BoxLayout(getContentPane(),BoxLayout.Y_AXIS);
        setLayout(layout);
        
        //previous = display.getFieldString();
        
        expanel = new JPanel();
        
           label = new JLabel("ȯ�漳��");
           expanel.add(label);
           
   
        setpanel = new JPanel();
        
           label1 = new JLabel("�⺻��κ���");
           textField = new JTextField();
           
           button1 = new JButton("Ȯ��");
           button1.addActionListener(this);
	       setpanel.add(label1);
	       setpanel.add(textField);
	       setpanel.add(button1);
	       setpanel.setLayout(new GridLayout(0,3));
	         
        add(expanel);
        add(setpanel);
        setVisible(true);
        
    }
   
         
   @Override
   public void actionPerformed(ActionEvent e) {
      // TODO Auto-generated method stub
      if(e.getSource() == button1) {
    	  
         changePath = textField.getText();                          		//previous���� �ȵ��� ������ �ذ��ϸ� ���� ��.
         try {
			previous = db.getpath();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1);;
		}
         System.out.println("previous : "+previous);
         System.out.println("changePath :"+changePath);
         db.updaterecord("pathtable","pathname", previous, changePath);
         int choice =JOptionPane.showConfirmDialog(null, "�⺻ ��θ� �ٲ� ����� �ؾ��մϴ�, �շ��Ͻðڽ��ϱ�?", "�˸�â", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
         System.out.println("choice : "+choice);
         if(choice==0) {
        	 System.exit(0);
         }
         else if(choice == 1) {
        	 setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
         }
          }
      
   }

}