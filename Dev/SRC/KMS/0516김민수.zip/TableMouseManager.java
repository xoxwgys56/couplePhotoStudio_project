package input;

import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import framework.IconObject;

public class TableMouseManager extends MouseAdapter implements MouseListener {

	private IconObject iconObject;
	
	public TableMouseManager(IconObject iconObject) {
		this.iconObject = iconObject;
	}
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("!!!!!!;;;;");
		// TODO Auto-generated method stu
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		System.out.println("!!!!!!;;;;");
	}

	@Override
	public void mouseExited(MouseEvent e) {
	
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
	}
}
