package framework;

import java.awt.image.BufferedImage;

import javax.swing.JLabel;

import input.TableMouseManager;

public  class IconObject extends JLabel{
	boolean focus;
	int icon_x, icon_y;
	BufferedImage image;
	String name;
	String path;
	TableMouseManager tableMouseManager;
	
	IconObject () {
		tableMouseManager = new TableMouseManager(this);
		this.addMouseListener(tableMouseManager);
		
	}


}
