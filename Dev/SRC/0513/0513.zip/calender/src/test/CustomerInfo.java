package test;

import java.util.Date;

public class CustomerInfo {
	String name;
	String phoneNum;
	String photoType;
	int num;
	int numOfPeople=1;
	String creationDate;
	String reservationDate;
	String lastDate;
	String calibrationInfo;
	int charge;
	
	public CustomerInfo(int c_num,String c_name, String c_phone, String c_kindofshut, int c_howmany, String c_date, String c_update,int pay, String bigo) {
		name=c_name;
		phoneNum=c_phone;
		photoType=c_kindofshut;
		numOfPeople=c_howmany;
		reservationDate=c_date;
		num=c_num;
		calibrationInfo=c_update;
		charge=pay;
		System.out.println(name);
	}
	public int getnum() {
		return num;
	}
}
