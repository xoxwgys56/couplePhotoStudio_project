package test;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ButtonPanel extends JPanel implements ActionListener{
	private JButton customerAddBtn;
	private JButton customerDeleteBtn;
	private JButton calenderBtn;
	private Vector<CustomerInfo> c_vec;
	private ListPanel lp;
	public ButtonPanel(Vector<CustomerInfo> vec,ListPanel l) {
		c_vec=vec;
		lp=l;
		this.setSize(84, 472);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0};
		gridBagLayout.rowHeights = new int[]{46, 46, 46,0};
		gridBagLayout.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		customerAddBtn = new JButton("�����߰�");
		customerAddBtn.addActionListener(this);
		customerAddBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		GridBagConstraints gbc_customerAddBtn = new GridBagConstraints();
		gbc_customerAddBtn.insets = new Insets(0, 0, 5, 0);
		gbc_customerAddBtn.fill = GridBagConstraints.HORIZONTAL;
		gbc_customerAddBtn.fill = GridBagConstraints.VERTICAL;
		gbc_customerAddBtn.gridx = 0;
		gbc_customerAddBtn.gridy = 0;
		add(customerAddBtn, gbc_customerAddBtn);
		
		customerDeleteBtn = new JButton("��������");
		customerDeleteBtn.addActionListener(this);
		customerDeleteBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		GridBagConstraints gbc_customerDeleteBtn = new GridBagConstraints();
		gbc_customerDeleteBtn.anchor = GridBagConstraints.EAST;
		gbc_customerDeleteBtn.fill = GridBagConstraints.HORIZONTAL;
		gbc_customerDeleteBtn.fill = GridBagConstraints.VERTICAL;
		gbc_customerDeleteBtn.gridx = 0;
		gbc_customerDeleteBtn.gridy = 1;
		add(customerDeleteBtn, gbc_customerDeleteBtn);
		
		calenderBtn = new JButton("Ķ����");
		calenderBtn.addActionListener(this);
		calenderBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
		GridBagConstraints gbc_calenderBtn = new GridBagConstraints();
		gbc_calenderBtn.anchor = GridBagConstraints.EAST;
		gbc_calenderBtn.fill = GridBagConstraints.HORIZONTAL;
		gbc_calenderBtn.fill = GridBagConstraints.VERTICAL;
		gbc_calenderBtn.gridx = 0;
		gbc_calenderBtn.gridy = 2;
		add(calenderBtn,gbc_calenderBtn);
		
	}
	@Override
    public void actionPerformed(ActionEvent e) {
		if (e.getSource() == customerAddBtn) {
			AddFrame adfr=new AddFrame(c_vec,lp);
		}
    }

}
