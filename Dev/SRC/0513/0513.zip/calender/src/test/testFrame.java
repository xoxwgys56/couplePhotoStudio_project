package test;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;

public class testFrame{

	public static void main(String[] args) {
		Display as=new Display();
	}
	
	
}

