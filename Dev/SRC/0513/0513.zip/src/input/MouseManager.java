package input;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseManager extends MouseAdapter implements MouseListener{

	public int cursor_x = -100, cursor_y = -100;//0���� �ʱ�ȭ�Ǿ�, ù��° �������� ���õǴ� ���� ����.
	public boolean cursor_in;
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		if (e.getModifiers() == MouseEvent.BUTTON1_MASK)
			System.out.println("left");
		else if (e.getModifiers() == MouseEvent.BUTTON3_MASK)
			System.out.println("right");
		else if (e.getModifiers() == MouseEvent.BUTTON2_MASK)
			System.out.println("middle");
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		this.cursor_in = true;
	}

	@Override
	public void mouseExited(MouseEvent e) {
		this.cursor_in = false;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		this.cursor_x = e.getX();
		this.cursor_y = e.getY();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		//�ν��� �ȵȴ� �������� �𸣰���.
		//this.cursor_x = e.getX();
		//this.cursor_y = e.getY();
	}

}
