package util;

import java.awt.Image;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class FileLoader {

	private String path;
	private String[] fileName;
	private String[] filePath;
	public String[] getFileName() {
		return fileName;
	}

	public String[] getFilePath() {
		return filePath;
	}

	private ImageIcon[] icon;
	
	private int size = 100;
	private File folder;
	private int fileCount;
	
	private ImageIcon folderImage;
	private ImageIcon rawImage;
	private ImageIcon nefImage;
	private ImageIcon crwImage;
	private ImageIcon arwImage;

	public FileLoader(String path) {
		icon = new ImageIcon[size];
		fileName = new String[size];
		filePath = new String[size];
		this.path = path;

	//	ImageIcon originIcon = null;
	//	Image originImg = null;
	//	Image changedImg = null;
		//�̹��� ũ�� ����
		ImageIcon originIcon = new ImageIcon("res/folder.png");  
		Image originImg = originIcon.getImage(); 
		Image changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		folderImage = new ImageIcon(changedImg);
		
		originIcon = new ImageIcon("res/raw.png");  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		rawImage = new ImageIcon(changedImg);		

		originIcon = new ImageIcon("res/nef.png");  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		nefImage = new ImageIcon(changedImg);

		originIcon = new ImageIcon("res/crw.png");  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		crwImage = new ImageIcon(changedImg);

		originIcon = new ImageIcon("res/arw.png");  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		arwImage = new ImageIcon(changedImg);
		
		//�̹��� ũ�� ����
	//	setImage("res/folder.png", folderImage, originIcon, originImg, changedImg);
	//	setImage("res/raw.png", rawImage, originIcon, originImg, changedImg);	
	//	setImage("res/nef.png", nefImage, originIcon, originImg, changedImg);	
	//	setImage("res/crw.png", crwImage, originIcon, originImg, changedImg);	
		
	}

	public void LoadFiles(File folder) {
		
		if (!folder.exists())
			return;
		icon = new ImageIcon[size];

		int i = 0;
		this.path = folder.getAbsolutePath();
		
		fileCount = 0;
		for (File fileEntry : folder.listFiles()) {
			this.fileCount++;
			if (fileEntry.isDirectory()) {
				filePath[i] = fileEntry.getAbsolutePath();
				fileName[i] = fileEntry.getName();
				icon[i++] = folderImage;
				
			} else {
				fileName[i] = fileEntry.getName();
				filePath[i] = fileEntry.getAbsolutePath();
				// Ȯ���� �˻�
				int pos = fileName[i].lastIndexOf('.');
				// ����Ȯ���ڰ� raw Ȥ�� RAW���
				switch( fileName[i].substring(pos+1) ) {
				/** Nikon */
				case "NEF" :
				case "nef" :
				case "nrw" :
				case "NRW" :
					icon[i++] = nefImage;	
					break;
				/** Cannon */
				case "crw" :
				case "CRW" :
				case "cr2" :
				case "CR2" :
				case "cr3" :
				case "CR3" :
					icon[i++] = crwImage;	
					break;
				/** Sony */
				case "arw" :
				case "ARW" :
					icon[i++] = arwImage;	
					break;
				/** Fuji film*/
				case "raw" :
				case "RAW" :
				case "raf" :
				case "RAF" :
					icon[i++] = rawImage;
					break;
				// ���� ���ϸ� ǥ�õǰ�
				case "jpg" :
				case "bmp" :
				case "gif" :
				case "png" : 
					Image originImg = new ImageIcon(filePath[i]).getImage();  
					Image changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
					icon[i++] = new ImageIcon(changedImg);
					break;
				default :
					fileCount--;
					break;
				}
			}
		}
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public ImageIcon[] getIcon() {
		return icon;
	}
	
	public File getFolder() {
		return this.folder;
	}
	
	public int getFileCount() {
		return fileCount;
	}
	
	public void setImage(String imageName, ImageIcon image,ImageIcon originIcon, Image originImg, Image changedImg) {
		originIcon = new ImageIcon(imageName);  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		image = new ImageIcon(changedImg);
	}

}
