package framework;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import database.DB_insert;
import util.FileLoader;

/*
 * setPath�� ����, path ������Ʈ�� �ʿ��ϴ�.
 * */

public class Display extends JFrame{

	private JPanel panel;
	private CanvasPanel canvas;
	private JTextField field;
	
	public String path;
	private int width, height;
	private String photoshopPath = "C:/Program Files/Adobe/Adobe Photoshop CC 2018/Photoshop.exe";//"C:/Windows/System32/notepad.exe";// �޸������� �س���.
	private String lightroomPath = "C:/Windows/System32/notepad.exe";// �޸������� �س���.
	private JScrollPane scroll;
	private ListPanel listpan;
	private ButtonPanel btnpan;
	static Vector<CustomerInfo> c_vec;
	private GridBagConstraints gbc_panel_1;
	private DropTarget dt;
	private FileLoader fileLoader;

	Dimension res = Toolkit.getDefaultToolkit().getScreenSize();	
	private String[] rawList = {
			/** for test */
			"raw", "RAW",
			/** Nikon */
			"NEF", "nef", "nrw", "NRW",
			/** Cannon */
			"crw", "CRW", "cr2", "CR2", "cr3", "CR3",
			/** Sony */
			"arw", "ARW",
			/** Fuji film*/
			"raf", "RAF"};

	public Display() {
		this.width = res.width;
		this.height = res.height;
		path = "C:/";
		init();
		//default path
		
	}
	
	public Display(String path) {
		this.width = res.width;
		this.height = res.height;
		this.path = path;
		
		init();
	}
	
	public void init() {
		this.setTitle("title");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		GridBagConstraints gbc_panel = new GridBagConstraints();
		c_vec=new Vector(1);
		setSize(1000,800);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{294, 436, 84, 0};
		gridBagLayout.rowHeights = new int[]{472, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 1.0, 0.0};
		gridBagLayout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		listpan= new ListPanel(this);
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 0;
		getContentPane().add(listpan, gbc_panel);
		
		btnpan=new ButtonPanel(c_vec,listpan);
		gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 3;
		gbc_panel.gridy = 0;
		getContentPane().add(btnpan, gbc_panel);
		
		panel = new JPanel();
		gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 2;
		gbc_panel_1.insets = new Insets(0, 0, 0, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 0;
		getContentPane().add(panel, gbc_panel_1);
		
	
		canvas = new CanvasPanel(); 
		canvas.setLayout(new FlowLayout(FlowLayout.LEFT,10,10));

		// ��������� ���� Ŭ���� �ۼ�
		class DisDropTargetListener implements DropTargetListener {
					
			// ���� ��� �� �̺�Ʈ ó��
			@Override
			public void drop(DropTargetDropEvent dtde) {				
					
				//�׼��� Copy Ȥ�� move �� ��� ����
				if ((dtde.getDropAction() & DnDConstants.ACTION_COPY_OR_MOVE) != 0) {

			            dtde.acceptDrop(dtde.getDropAction());
			            Transferable tr = dtde.getTransferable();

			            try {
			                //���ϸ� ������
			                List list = (List) tr.getTransferData(DataFlavor.javaFileListFlavor);
			                
			                // ���� ���丮��ο� ����
			                fileCopy(list, path);
			                
			                // �ٽ� �׸���
							fileLoader = new FileLoader(getPath());
							fileLoader.LoadFiles(new File(getPath()));
							clean_render();
							render(fileLoader.getIcon(), fileLoader.getFilePath(), fileLoader.getFileName(),
									fileLoader.getFileCount());
			            }
			            catch (Exception e) {
			                e.printStackTrace();
			            }
				}
			}

			@Override
			public void dragEnter(DropTargetDragEvent arg0) {}
			public void dragExit(DropTargetEvent arg0) {}
			public void dragOver(DropTargetDragEvent arg0) {}
			public void dropActionChanged(DropTargetDragEvent arg0) {}
		}
		// ��������� ��ü ������
		DisDropTargetListener dtl = new DisDropTargetListener();
		
		// ��� Ÿ�� ��ü ���� 
		dt = new DropTarget(canvas,DnDConstants.ACTION_COPY_OR_MOVE,
                dtl,true,null); 
		
		scroll = new JScrollPane(canvas,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		//scroll.setPreferredSize(new Dimension(300,300));
		field = new JTextField();
		
		panel.setSize(512, 512);
		panel.setBorder(BorderFactory.createLineBorder(Color.black));
		panel.setLayout(new BorderLayout());
		
		field.setSize(100, 100);
		field.setText(path);
		field.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				path = field.getText();
				System.out.println(path);
			}
		});
		
		panel.add(scroll, "Center");
		panel.add(field, "North");
		
		
		setVisible(true);
		
		DB_insert dbi =new DB_insert();
		c_vec.removeAllElements();
		try {
			dbi.getRecord(c_vec);
		}
		catch(SQLException se) {
			System.out.println(se);
		}
		listpan.setList(c_vec);
	}
	
	public void render(ImageIcon[] icon, String[] filePath, 
			String[] fileName, int count) {
		canvas.setPreferredSize(new Dimension(200,count * 30));
		
		for ( int i = 0 ; i < count ; i++ ) {
			JLabel label = new JLabel();
			int pos = filePath[i].lastIndexOf('.');
			File colorFile = null;
			
			if ( pos != -1)
				colorFile = new File( filePath[i].substring(0,pos) + ".color");
			
			// ������
			label.setIcon(icon[i]);
			label.setPreferredSize(new Dimension(90,90));
			// ���� ���̺�
			JLabel colorLabel = new JLabel(" ");
			colorLabel.setOpaque(true);
			colorLabel.setPreferredSize(new Dimension(20,20));
			colorLabel.setVerticalAlignment(SwingConstants.TOP);
			colorLabel.setBackground(Color.white);	
			// ���� ����
			if ( pos == -1 ) {
				colorLabel.setBackground(Color.white);	
			}
			else {
			    if ( colorFile.exists() == false) {
					colorLabel.setBackground(Color.white);	
					System.out.println(filePath[i]);
			    }
			    else {
				    // �����б�
				    try {
				        BufferedReader in = new BufferedReader(new FileReader(colorFile));
				        int r, g, b;
				        r = Integer.parseInt(in.readLine());
				        g = Integer.parseInt(in.readLine());
				        b = Integer.parseInt(in.readLine());
				        System.out.println(r +" " + g + " " +b);
				        in.close();
					    colorLabel.setBackground(new Color(r,g,b));
				        
				    } catch (IOException e) {
				          e.printStackTrace();
				    }
			    }
			}
			JLabel dummyLabel = new JLabel(" ");
			dummyLabel.setPreferredSize(new Dimension(20,40));
			// ���� �˾�
			JPopupMenu colorPopup = new JPopupMenu();
        	//�޴�������		
        	JMenuItem white = new JMenuItem("white");
        	JMenuItem black = new JMenuItem("black");
        	JMenuItem red = new JMenuItem("red");
        	JMenuItem green = new JMenuItem("green");
        	JMenuItem blue = new JMenuItem("blue");
        	
        	colorPopup.add(white);
        	colorPopup.add(black);
        	colorPopup.add(red);
        	colorPopup.add(green);
        	colorPopup.add(blue);
        	
        	class ActionClass implements ActionListener
        	{
        		File colorFile;
        		public ActionClass(File colorFile) {
        			this.colorFile = colorFile;
        		}
        		@Override
        		public void actionPerformed(ActionEvent e) {
        			String obj = e.getActionCommand();
        			BufferedWriter out = null;
        			String r = null, g = null, b = null;
        			try {
						out = new BufferedWriter(new FileWriter(colorFile));
					} catch (IOException e1) {
						e1.printStackTrace();
					}
        			System.out.println(obj);
        			switch( obj ) {
        			case "white": colorLabel.setBackground(Color.white); 
        						  r = "255\n"; g = "255\n"; b = "255\n";
        						  break;
        			case "black": colorLabel.setBackground(Color.black); 
					  			  r = "0\n"; g = "0\n"; b = "0\n";
        						  break;
        			case "red"	: colorLabel.setBackground(Color.red); 
		  			  			  r = "255\n"; g = "0\n"; b = "0\n";	 
		  			  			  break;
        			case "green": colorLabel.setBackground(Color.green); 
		  			  			  r = "0\n"; g = "255\n"; b = "0\n"; 
		  			  			  break;
        			case "blue"	: colorLabel.setBackground(Color.blue); 
		  			  			  r = "0\n"; g = "0\n"; b = "255\n";	 
		  			  			  break;
        			}
					try {
						out.write(r);
					    out.write(g);
					    out.write(b);
					    out.flush();
					} catch (IOException e1) {
						e1.printStackTrace();
					} 
        		}
        	}
        	// �̺�Ʈ ������
            white.addActionListener(new ActionClass(colorFile));
            black.addActionListener(new ActionClass(colorFile));
            red.addActionListener(new ActionClass(colorFile));
            green.addActionListener(new ActionClass(colorFile));
            blue.addActionListener(new ActionClass(colorFile));

            colorLabel.add(colorPopup);
			colorLabel.addMouseListener(new MouseAdapter(){
				//���콺 Ŭ��
			    public void mousePressed(MouseEvent evnt) {
			    	// ��Ŭ����
			        if (evnt.getModifiers() == MouseEvent.BUTTON3_MASK) {
			        	//�˾�
			        	colorPopup.show(label, evnt.getX(), evnt.getY());
			        }
			     }
			});
			
			
			// �����̸�
			StringBuffer strbf = new StringBuffer();
			strbf.append("<html>"); 
			int begin = 0 , end = 8;
			int leng = fileName[i].length();
		
			do {
				// ������ ���� break
				if ( end > leng) {
					end = leng;
				}

				strbf.append(fileName[i].substring(begin, end) + "<br>");
				begin = end;
				
				if ( end == leng)
					break;
				
				end += 8;
				
			} while(true);
			
			strbf.append("</html>");
			
			JLabel nameLabel = new JLabel(strbf.toString());
			nameLabel.setPreferredSize(new Dimension(70,60));
			nameLabel.setVerticalAlignment(SwingConstants.TOP);
		
			// ���̺��� �гο� ����
			JPanel iconPanel = new JPanel();
			iconPanel.setLayout(new BorderLayout());
			iconPanel.add(label, BorderLayout.CENTER);
			JPanel colorPanel = new JPanel();
			colorPanel.setLayout(new BorderLayout());
			colorPanel.add(colorLabel, BorderLayout.NORTH);
			colorPanel.add(dummyLabel, BorderLayout.CENTER);
			JPanel namePanel = new JPanel();
			namePanel.add(colorPanel);
			namePanel.add(nameLabel);
			iconPanel.add(namePanel, BorderLayout.SOUTH);
		
			colorPanel.setOpaque(false);
			namePanel.setOpaque(false);
			iconPanel.setOpaque(false);
			//�˾�
			JPopupMenu popup = new JPopupMenu();
        	//�޴�������		
        	JMenuItem open = new JMenuItem("����");
        	JMenuItem delete = new JMenuItem("����");
        	JMenuItem open_photo = new JMenuItem("���伥���� ����");
        	JMenuItem edit = new JMenuItem("����Ʈ������ ����");
        	JMenuItem add_memo = new JMenuItem("�޸�");

			// �˾�
			JPopupMenu folder_popup = new JPopupMenu();
			// �޴�������
			JMenuItem folder_open = new JMenuItem("����");
			JMenuItem folder_delete = new JMenuItem("����");
			
			folder_popup.add(folder_open);
			folder_popup.add(folder_delete);
			
			String filepath = filePath[i];

        	popup.add(open);
        	popup.add(delete);
        	popup.add(open_photo);
        	popup.add(edit);
        	popup.add(add_memo);

        	///////////////////////////////////
			// �˾�
			JPopupMenu raw_popup = new JPopupMenu();
			// �޴�������
			JMenuItem raw_open = new JMenuItem("����");
			JMenuItem raw_delete = new JMenuItem("����");
			JMenuItem raw_open_photo = new JMenuItem("���伥���� ����");
        	JMenuItem raw_edit = new JMenuItem("����Ʈ������ ����");
        	JMenuItem raw_add_memo = new JMenuItem("�޸�");
        	
			raw_popup.add(raw_open);
			raw_popup.add(raw_delete);
			raw_popup.add(raw_open_photo);
			raw_popup.add(raw_edit);
			raw_popup.add(raw_open);
			raw_popup.add(raw_delete);
			raw_popup.add(raw_add_memo);
        	
			class PopupActionClass implements ActionListener {
				@Override
				public void actionPerformed(ActionEvent e) {
					String obj = e.getActionCommand();
					System.out.println(obj);
					switch (obj) {
					case "����":
						try {
							Desktop.getDesktop().open(new File(filepath));
						} catch (IOException e1) {
							e1.printStackTrace();
						}
						break;
					case "����":
						if (!new File(filepath).delete()) {
							// ���� �Ұ���
							System.out.println("error::delete failed");
						} else {
							System.out.println("delete successed");
						}
						break;
					case "���伥���� ����":
						File photoshop_file = new File(filepath);
						ProcessBuilder photoshop_builder = new ProcessBuilder(photoshopPath, photoshop_file.getAbsolutePath());
						photoshop_builder.redirectErrorStream();
						photoshop_builder.redirectOutput();
						Process photoshop_process;
						try {
							photoshop_process = photoshop_builder.start();
							photoshop_process.waitFor();
						} catch (IOException e1) {
							e1.printStackTrace();
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
						break;
					case "����Ʈ������ ����":
						File lightroon_file = new File(filepath);
						ProcessBuilder lightroon_builder = new ProcessBuilder(lightroomPath,
								lightroon_file.getAbsolutePath());
						lightroon_builder.redirectErrorStream();
						lightroon_builder.redirectOutput();
						Process lightroon_process;
						try {
							lightroon_process = lightroon_builder.start();
							lightroon_process.waitFor();
						} catch (IOException e1) {
							e1.printStackTrace();
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
						break;
					case "�޸�":
						String input_memo = JOptionPane.showInputDialog("input memo");
						if (input_memo == null)
							System.out.println("no input memo");
						else {
							System.out.println("input memo is " + input_memo);
							System.out.println(filepath);
							int pos = filepath.lastIndexOf('.');
							try {
								BufferedWriter out = new BufferedWriter(
										new FileWriter(filepath.substring(0, pos) + ".txt"));
								out.write(input_memo);
								out.newLine();
								out.close();
							} catch (IOException e2) {
								e2.printStackTrace();
							}
						}
						break;
					}
					FileLoader fileLoader = new FileLoader(getPath());
					fileLoader.LoadFiles(new File(getPath()));
					clean_render();
					render(fileLoader.getIcon(), fileLoader.getFilePath(), fileLoader.getFileName(),
							fileLoader.getFileCount());
				}
			}
	 	
        	// �̺�Ʈ ������
            open.addActionListener(new PopupActionClass());
        	delete.addActionListener(new PopupActionClass());
        	open_photo.addActionListener(new PopupActionClass());
        	edit.addActionListener(new PopupActionClass());
        	add_memo.addActionListener(new PopupActionClass());
			folder_open.addActionListener(new PopupActionClass());
			folder_delete.addActionListener(new PopupActionClass());
        	
        	label.add(popup);
			label.addMouseListener(new MouseAdapter(){
				// ���콺 Ŭ��
				public void mousePressed(MouseEvent evnt) {
					// ��Ŭ����
					if (evnt.getModifiers() == MouseEvent.BUTTON3_MASK) {
						File file = new File(filepath);
						if (file.isDirectory())
							folder_popup.show(label, evnt.getX(), evnt.getY());
						else if (isRawFile(file)) {
							
						}
						else
							popup.show(label, evnt.getX(), evnt.getY());
					}
				}/*�߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰��߰�*/
			    //���콺 �ȿ� �޸� ����
			    public void mouseEntered(MouseEvent evnt ) {
			    	int pos = filepath.lastIndexOf('.');
			    	// ���͸��ϰ��
			    	if ( pos == -1 ) return;
			    	
				    File memofile = new File( filepath.substring(0,pos) + ".txt");
				    // �޸� �������
				    if ( memofile.exists() == false) return;
				    
				    StringBuffer memo_sb = new StringBuffer();
				    
				    try {
				        BufferedReader in = new BufferedReader(new FileReader(memofile));
				        String str;
				        // �ٹٲ����� html �±�����
				        memo_sb.append("<html>");
				        while ((str = in.readLine()) != null) {
				          memo_sb.append(str + "<br>");
				        }
				        memo_sb.append("</html>");
				        in.close();
				    } catch (IOException e) {
				          e.printStackTrace();
				    }
				    // ���� ����
			    	label.setToolTipText(memo_sb.toString());
			    }

			});
			canvas.add(iconPanel);
		}
		
		/*BufferedImage myPicture = null;
		try {
			myPicture = ImageIO.read(new File("C:/bagu.jpg"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		JLabel picLabel = new JLabel(new ImageIcon(myPicture));
	
		canvas.setOpaque(true);
		canvas.add(picLabel);
	*/	
		canvas.validate();
		canvas.repaint();
		scroll.validate();
		scroll.repaint();
		
		
	}
	// render ��
	
	
	/** add add add add add add add add add add add add add add add add add add add add add add add add */
	private boolean isRawFile(File file) {
		int pos = file.getName().lastIndexOf('.');
		String name = file.getName().substring(pos+1);
		for (int i=0; i<rawList.length; i++) {
			if (name.equals(rawList[i]))
				return true;
		}
		return false;
	}
	
	// ����� ���� ����
	public void fileCopy(List list, String path) {
		File dir = new File(path);
		int n;
		String name;
		for ( int i = 0; i < list.size() ; i++) {
			// �ҽ� ���� 
			
	        File srcfile = (File)list.get(i);
	        DataInputStream dis = null;
	        DataOutputStream dos = null;
	        
	        File outfile = new File(path, srcfile.getName());
	        try {
	           
	            dis = new DataInputStream(new BufferedInputStream(new FileInputStream(srcfile)));
	            dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outfile)));
          
	            // ���� �а� ����
	            while((n = dis.read()) != -1){
	            	dos.write(n);
	            }
            	dos.flush();
            	
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (dis != null) try {dis.close(); } catch (IOException e) {}
	            if (dos != null) try {dos.close(); } catch (IOException e) {}
	        } 
		}
		
	}

	public void clean_render() {
		
		canvas.removeAll();
	}
	
	public JFrame getFrame() {		
		return this;
	}
	public JPanel getPanel() {
		return panel;
	}

	public JPanel getCanvas() {
		return canvas;
	}

	public JTextField getField() {
		return field;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getPath() {
		return path;
	}

	public String getFieldString() { //
		return field.getText();
	}
	
	public void setPath(String path) {
		this.path = path;
	}

}
