package test;

public class TableFrameWork {

	private Display display;
	private String path;
	private ImageTablePanel imgTablepanel;
	
	public TableFrameWork(String path) {
		this.path = path;
		
		init();
	}
	
	private void init() {
		imgTablepanel = new ImageTablePanel();
		display = new Display(path);
		display.add(imgTablepanel);
	}
	
}
