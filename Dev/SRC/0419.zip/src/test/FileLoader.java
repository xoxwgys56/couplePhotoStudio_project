package test;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class FileLoader {

	private String path;
	
	private String[] fileList;
	private BufferedImage[] imageList;
	private ImageIcon[] icon;
	private int size = 100;
	
	public FileLoader(String path) {
		imageList = new BufferedImage[size];
		fileList = new String[size];
		icon = new ImageIcon[size];
		
		this.path = path;
	}
	
	public FileLoader() {
		//imageList = new BufferedImage[size];
		fileList = new String[size];
		icon = new ImageIcon[size];
		
		//default path
		this.path = "C:/";
	}
	
	/*
	 * path ���� ó������� ��.
	 * 1. ���丮�� ���
	 * 2. ������ ���
	 * 3. �߸��� ����� ���
	 * 4. ��Ʈ�� �ִ��� ������
	 * */
	
	public void LoadFiles(File folder) {
		imageList = new BufferedImage[size];
		
		int i = 0;
		this.path = folder.getAbsolutePath();
		
		for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				//System.out.println("dir : "+fileEntry.getName());
			}
			else {
				fileList[i] = fileEntry.getAbsolutePath();
				icon[i] = new ImageIcon(fileEntry.getAbsolutePath());
				
				try {
					imageList[i++] = ImageIO.read(fileEntry);
				} catch(IOException e) {}
			}
		}
		
	}
	
	public void LoadFiles() {
		imageList = new BufferedImage[size];
		
		File folder = new File(path);
		
		int i = 0;
		
		for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				//System.out.println("dir : "+fileEntry.getName());
			}
			else {
				fileList[i] = fileEntry.getAbsolutePath();
				icon[i] = new ImageIcon(fileEntry.getAbsolutePath());
				
				try {
					imageList[i++] = ImageIO.read(fileEntry);
				} catch(IOException e) {}
			}
		}
		
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String[] getFileList() {
		return fileList;
	}

	public BufferedImage[] getImageList() {
		return imageList;
	}
	
	public ImageIcon[] getIcon() {
		return icon;
	}
}
