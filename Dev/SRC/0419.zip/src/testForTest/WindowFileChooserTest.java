package testForTest;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class WindowFileChooserTest {

	public static void main(String[] args) {
		String path = "D:/testImg";
		/*
		try {
			Runtime.getRuntime().exec("explorer.exe /select," + path);
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		File file = new File ("c:/");
		Desktop desktop = Desktop.getDesktop();
		try {
			desktop.open(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
