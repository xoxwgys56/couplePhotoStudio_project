package testForTest;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class JFileChooserTest {

	static JEditorPane webWindow;
	
	public static void main(String[] args) {
		webWindow = new JEditorPane();
		webWindow.setEditable(false);

		JMenuBar menu = new JMenuBar();
		setJMenuBar(menu);

		JMenu file = new JMenu("File");
		    menu.add(file);

		JMenuItem open = new JMenuItem("Open file...");
		    file.add(open);
		    open.addActionListener(
		    // new detector
		    new ActionListener() {
		    	JFileChooser chooser = new JFileChooser();
	            chooser.setCurrentDirectory(new java.io.File("."));
	            chooser.setSelectedFile(new File(""));
	            chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	            // chooser.setAcceptAllFileFilterUsed(false);
	            if (chooser.showOpenDialog(frame) == JFileChooser.OPEN_DIALOG) {
	            //do when open
	            } else {
	                // do when cancel
	            }
		        // when detector is tripped, perform this action
		        public void actionPerformed(ActionEvent enterPress) {
		            // gets string from JTextField using the loadWebPage method
		            try {
		                Desktop.getDesktop().open(new File("c:\\"));
		            } catch (IOException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		        }
		    });
	}
}
