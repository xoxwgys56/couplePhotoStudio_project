package BuBuPhotoshop;

import javax.swing.JFrame;

public class testFrame extends JFrame{
	ListPanel listpan;
	public testFrame() {
		setSize(500,800);
		listpan=new ListPanel();
		add(listpan);
		setVisible(true);
	}
	public static void main(String[] args) {
		testFrame as=new testFrame();
		CustomerInfo[] ci =new CustomerInfo[50];
		for(int i=0;i<ci.length;i++) {
			ci[i]=new CustomerInfo();
			ci[i].num=i;
			ci[i].name="ii";
			ci[i].reservationDate="aa";
		}
		as.listpan.setList(ci);
	}
}

