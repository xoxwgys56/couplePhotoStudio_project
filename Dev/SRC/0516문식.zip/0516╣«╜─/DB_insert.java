package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import framework.CustomerInfo;

public class DB_insert{
      public static Connection DB_insert() {
         
         
         String url = "jdbc:mysql://localhost/PICDB";
         String id = "root";  //id
         String password = "apmsetup"; //pw
         Connection con = null;
         //jdbc ����̹� ���� �Լ�
         try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("����̹� ���� ����");
            con = DriverManager.getConnection(url, id, password);
            System.out.println("������ ���̽� ���� ����");
            
         }
         catch(ClassNotFoundException e) {
            System.out.println("����̹��� ã�� �� �����ϴ�.");
         } catch (SQLException e) {
           
            System.out.println("���ῡ ���� !");
         }
         return con;
      }

      public static void getRecord(Vector<CustomerInfo> vec) throws SQLException{
    	  Connection con = DB_insert();
          Statement stmt = con.createStatement();  
          // ��ü�˻�
          ResultSet rs = stmt.executeQuery("Select * from PICTABLE"); 
          while(rs.next()) {
         	 
         	int num = rs.getInt("customnum");
             String c_name = rs.getString("customname");
             String c_phonenumber = rs.getString("tel");
             String kindofshut = rs.getString("type");
             int howmany = rs.getInt("people");
             String createdate = rs.getString("createdate");
             String date = rs.getString("date");
             String finaldate = rs.getString("finaldate");
             int pay = rs.getInt("paid");
             String bigo = rs.getString("bigo");

             CustomerInfo ci =new CustomerInfo(num, c_name, c_phonenumber, kindofshut, 
            		 howmany, createdate, date, finaldate, pay, bigo);

             vec.addElement(ci);
          }
      }
      //��� �� ���
      public static String getpath() throws SQLException{
    	Connection con = DB_insert();
        Statement stmt = con.createStatement();
        
        ResultSet rs = stmt.executeQuery("Select pathname from pathtable");
        String path = null;
        if(rs.next()) {
		path = rs.getString("pathname");
        }
        else {
        	System.out.println("�Ӽ��� �� �����ϴ�");
        }
        return path;
        
      }
      //����
      public static void addrecord(String c_name, String c_phone, String c_kindofshut, int c_howmany, String c_date, int pay, String bigo) 
      {
    	 
    	  Connection con = DB_insert();
          try {
        	  Statement stmt = con.createStatement();
        	  String s = "insert into pictable(customname, tel, type, people, createdate, date, finaldate, paid, bigo)values";
        	  Date today = new Date();
        	  SimpleDateFormat date = new SimpleDateFormat("yy-MM-dd");
        	  s+= "('"+c_name+"','"+c_phone+"','"+c_kindofshut+"','"+ c_howmany+"','"+ date.format(today)+"','"+c_date+"','"+ " "+"','"+pay+"','"+bigo+"')";
        	  System.out.println(s);
        	  int i = stmt.executeUpdate(s);
        	  if(i == 1) System.out.println("���� ����");
        	  else System.out.println("���� ����");
          }catch (SQLException e) {
        	  System.out.println(e.getMessage());
        	  System.exit(0);
          }
      }
      //��λ���
      public static void addpath(String pathname) {
    	  
   
    	  Connection con = DB_insert();
          try {
        	  Statement stmt = con.createStatement();
        	  String s = "insert into pathtable values";
        	  		
        	  s+= "('"+pathname+"')";
        	  System.out.println(s);
        	  int i = stmt.executeUpdate(s);
        	  if(i == 1) System.out.println("���� ����");
        	  else System.out.println("���� ����");
          }catch (SQLException e) {
        	  System.out.println(e.getMessage());
        	  System.exit(0);
          }
      }
      //���ڵ� ����
      public static void deleterecord(String column,String deleterecord) {
     	 Connection con = DB_insert();
     	 String s = "delete "+"from pictable where "+column+"="+"'"+deleterecord+"'";
     	 try {
         	 Statement stmt = con.createStatement();
         	 System.out.println(s);
              int i = stmt.executeUpdate(s);
              if(i == 1) System.out.println("Ʃ�� ���� ����");
              else System.out.println("Ʃ�� ���� ����");
          }catch (SQLException e) {
        	  System.out.println(e.getMessage());
        	  System.exit(0);
          }
      
      }
      //pictable ���� 0516�߰�
      public static void updatecustomer(String pathname, String after,String c_num) {
    	  Connection con = DB_insert();
          String s = "update pictable set "+pathname+"="+"'"+after+"'"+" where customnum="+"'"+c_num+"'";
          
         try {
        	 Statement stmt = con.createStatement();
        	 System.out.println(s);
             int i = stmt.executeUpdate(s);
             if(i == 1) System.out.println("���� ����");
             else System.out.println("���� ����");
         }catch (SQLException e) {
       	  System.out.println(e.getMessage());
       	  System.exit(0);
         }
         
      }
      //����								//���̺� ��    	//�ٲ� �Ӽ�		//�ٲ�� �� ��		//�ٲ���� ��
      public static void updaterecord(String pathtable,String pathname,String before, String after) {
    	  Connection con = DB_insert();
    	  System.out.println("before : "+before);
          String s = "update "+pathtable+ " set "+pathname+"="+"'"+after+"'"+" where "+pathname+"="+"'"+before+"'";
          
         try {
        	 Statement stmt = con.createStatement();
        	 System.out.println(s);
             int i = stmt.executeUpdate(s);
             if(i == 1) System.out.println("���� ����");
             else System.out.println("���� ����");
         }catch (SQLException e) {
       	  System.out.println(e.getMessage());
       	  System.exit(0);
         }
         
      }

}