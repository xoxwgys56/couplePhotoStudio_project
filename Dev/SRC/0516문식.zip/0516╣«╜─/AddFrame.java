package framework;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import database.DB_insert;

public class AddFrame extends JFrame implements ActionListener{
	private JTextField c_nameTextField;
	private JTextField c_pnumextField;
	private JTextField photoTypeTextField;
	private JTextField reservationDateTextFieldyear;
	private JTextField numOfPeopleTextField;
	private Vector<CustomerInfo> c_vec;
	private ListPanel lp;
	JButton OKButton;
	JButton cancelButton;
	private JTextField reservationDateTextFieldmonth;
	private JTextField reservationDateTextFieldday;
	private JLabel Label1;
	private JLabel Label2;
	
	public AddFrame(Vector<CustomerInfo> vec,ListPanel l) {
		c_vec=vec;
		lp=l;
		this.setSize(445, 240);
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 117, 0, 121, 0, 114, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 16, 38, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel c_nameLabel = new JLabel("�����̸�");
		GridBagConstraints gbc_c_nameLabel = new GridBagConstraints();
		gbc_c_nameLabel.anchor = GridBagConstraints.EAST;
		gbc_c_nameLabel.insets = new Insets(0, 0, 5, 5);
		gbc_c_nameLabel.gridx = 0;
		gbc_c_nameLabel.gridy = 0;
		panel.add(c_nameLabel, gbc_c_nameLabel);
		
		c_nameTextField = new JTextField();
		GridBagConstraints gbc_c_nameTextField = new GridBagConstraints();
		gbc_c_nameTextField.gridwidth = 5;
		gbc_c_nameTextField.insets = new Insets(0, 0, 5, 0);
		gbc_c_nameTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_c_nameTextField.gridx = 1;
		gbc_c_nameTextField.gridy = 0;
		panel.add(c_nameTextField, gbc_c_nameTextField);
		c_nameTextField.setColumns(10);
		
		JLabel c_pnumLabel = new JLabel("��ȭ��ȣ");
		GridBagConstraints gbc_c_pnumLabel = new GridBagConstraints();
		gbc_c_pnumLabel.anchor = GridBagConstraints.EAST;
		gbc_c_pnumLabel.insets = new Insets(0, 0, 5, 5);
		gbc_c_pnumLabel.gridx = 0;
		gbc_c_pnumLabel.gridy = 1;
		panel.add(c_pnumLabel, gbc_c_pnumLabel);
		
		c_pnumextField = new JTextField();
		GridBagConstraints gbc_c_pnumextField = new GridBagConstraints();
		gbc_c_pnumextField.gridwidth = 5;
		gbc_c_pnumextField.insets = new Insets(0, 0, 5, 0);
		gbc_c_pnumextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_c_pnumextField.gridx = 1;
		gbc_c_pnumextField.gridy = 1;
		panel.add(c_pnumextField, gbc_c_pnumextField);
		c_pnumextField.setColumns(10);
		
		JLabel photoTypeLabel = new JLabel("�Կ�����");
		GridBagConstraints gbc_photoTypeLabel = new GridBagConstraints();
		gbc_photoTypeLabel.anchor = GridBagConstraints.EAST;
		gbc_photoTypeLabel.insets = new Insets(0, 0, 5, 5);
		gbc_photoTypeLabel.gridx = 0;
		gbc_photoTypeLabel.gridy = 2;
		panel.add(photoTypeLabel, gbc_photoTypeLabel);
		
		photoTypeTextField = new JTextField();
		GridBagConstraints gbc_photoTypeTextField = new GridBagConstraints();
		gbc_photoTypeTextField.gridwidth = 5;
		gbc_photoTypeTextField.insets = new Insets(0, 0, 5, 0);
		gbc_photoTypeTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_photoTypeTextField.gridx = 1;
		gbc_photoTypeTextField.gridy = 2;
		panel.add(photoTypeTextField, gbc_photoTypeTextField);
		photoTypeTextField.setColumns(10);
		
		JLabel reservationDateLabel = new JLabel("���೯¥");
		GridBagConstraints gbc_reservationDateLabel = new GridBagConstraints();
		gbc_reservationDateLabel.anchor = GridBagConstraints.EAST;
		gbc_reservationDateLabel.insets = new Insets(0, 0, 5, 5);
		gbc_reservationDateLabel.gridx = 0;
		gbc_reservationDateLabel.gridy = 3;
		panel.add(reservationDateLabel, gbc_reservationDateLabel);
		
		reservationDateTextFieldyear = new JTextField();
		GridBagConstraints gbc_reservationDateTextFieldyear = new GridBagConstraints();
		gbc_reservationDateTextFieldyear.insets = new Insets(0, 0, 5, 5);
		gbc_reservationDateTextFieldyear.fill = GridBagConstraints.HORIZONTAL;
		gbc_reservationDateTextFieldyear.gridx = 1;
		gbc_reservationDateTextFieldyear.gridy = 3;
		panel.add(reservationDateTextFieldyear, gbc_reservationDateTextFieldyear);
		reservationDateTextFieldyear.setColumns(10);
		
		Label1 = new JLabel("-");
		GridBagConstraints gbc_Label1 = new GridBagConstraints();
		gbc_Label1.insets = new Insets(0, 0, 5, 5);
		gbc_Label1.anchor = GridBagConstraints.EAST;
		gbc_Label1.gridx = 2;
		gbc_Label1.gridy = 3;
		panel.add(Label1, gbc_Label1);
		
		reservationDateTextFieldmonth = new JTextField();
		GridBagConstraints gbc_reservationDateTextFieldmonth = new GridBagConstraints();
		gbc_reservationDateTextFieldmonth.insets = new Insets(0, 0, 5, 5);
		gbc_reservationDateTextFieldmonth.fill = GridBagConstraints.HORIZONTAL;
		gbc_reservationDateTextFieldmonth.gridx = 3;
		gbc_reservationDateTextFieldmonth.gridy = 3;
		panel.add(reservationDateTextFieldmonth, gbc_reservationDateTextFieldmonth);
		reservationDateTextFieldmonth.setColumns(10);
		
		Label2 = new JLabel("-");
		GridBagConstraints gbc_Label2 = new GridBagConstraints();
		gbc_Label2.insets = new Insets(0, 0, 5, 5);
		gbc_Label2.anchor = GridBagConstraints.EAST;
		gbc_Label2.gridx = 4;
		gbc_Label2.gridy = 3;
		panel.add(Label2, gbc_Label2);
		
		reservationDateTextFieldday = new JTextField();
		GridBagConstraints gbc_reservationDateTextFieldday = new GridBagConstraints();
		gbc_reservationDateTextFieldday.insets = new Insets(0, 0, 5, 0);
		gbc_reservationDateTextFieldday.fill = GridBagConstraints.HORIZONTAL;
		gbc_reservationDateTextFieldday.gridx = 5;
		gbc_reservationDateTextFieldday.gridy = 3;
		panel.add(reservationDateTextFieldday, gbc_reservationDateTextFieldday);
		reservationDateTextFieldday.setColumns(10);
		
		JLabel numOfPeopleLabel = new JLabel("�ο� ��");
		GridBagConstraints gbc_numOfPeopleLabel = new GridBagConstraints();
		gbc_numOfPeopleLabel.anchor = GridBagConstraints.EAST;
		gbc_numOfPeopleLabel.insets = new Insets(0, 0, 5, 5);
		gbc_numOfPeopleLabel.gridx = 0;
		gbc_numOfPeopleLabel.gridy = 4;
		panel.add(numOfPeopleLabel, gbc_numOfPeopleLabel);
		
		numOfPeopleTextField = new JTextField();
		GridBagConstraints gbc_numOfPeopleTextField = new GridBagConstraints();
		gbc_numOfPeopleTextField.insets = new Insets(0, 0, 5, 0);
		gbc_numOfPeopleTextField.gridwidth = 5;
		gbc_numOfPeopleTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_numOfPeopleTextField.gridx = 1;
		gbc_numOfPeopleTextField.gridy = 4;
		panel.add(numOfPeopleTextField, gbc_numOfPeopleTextField);
		numOfPeopleTextField.setColumns(10);
		numOfPeopleTextField.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent ev) {
				keytyped(ev);
			}
		});
		
		OKButton = new JButton("�߰�");
		OKButton.addActionListener(this);
		GridBagConstraints gbc_OKButton = new GridBagConstraints();
		gbc_OKButton.insets = new Insets(0, 0, 0, 5);
		gbc_OKButton.fill = GridBagConstraints.BOTH;
		gbc_OKButton.gridx = 1;
		gbc_OKButton.gridy = 6;
		panel.add(OKButton, gbc_OKButton);
		
		cancelButton = new JButton("���");
		cancelButton.addActionListener(this);
		GridBagConstraints gbc_cancelButton = new GridBagConstraints();
		gbc_cancelButton.insets = new Insets(0, 0, 0, 5);
		gbc_cancelButton.fill = GridBagConstraints.BOTH;
		gbc_cancelButton.gridx = 3;
		gbc_cancelButton.gridy = 6;
		panel.add(cancelButton, gbc_cancelButton);
		
		this.setVisible(true);
	}
	private void keytyped(KeyEvent ev) {
		try {
			Integer.parseInt(Character.toString(ev.getKeyChar()));		//������ ��쿡��
	    } catch (NumberFormatException e) {
	    	numOfPeopleTextField.setText("");
	    	JOptionPane.showMessageDialog(this, "���ڸ� �Է��Ͻñ� �ٶ��ϴ�.");
	    }
	}
	@Override
    public void actionPerformed(ActionEvent e) {
		if (e.getSource() == OKButton) {
			if(c_nameTextField.getText().equals("")|| c_pnumextField.getText().equals("")|| photoTypeTextField.getText().equals("")|| numOfPeopleTextField.getText().equals("")
					|| reservationDateTextFieldyear.getText().equals("")) {
				JOptionPane.showMessageDialog(this, "�Է����� ������ ���� �ֽ��ϴ�.");
			}
			
			else {
				DB_insert di=new DB_insert();
				di.addrecord(c_nameTextField.getText(), c_pnumextField.getText(), photoTypeTextField.getText(), Integer.parseInt(numOfPeopleTextField.getText()), reservationDateTextFieldyear.getText(),  0, "");
				c_vec.removeAllElements();
				try {
					di.getRecord(c_vec);
				}catch(SQLException sqe) {
					
				}
             	lp.setList(c_vec);
             	dispose();
			}
			
		}
		if (e.getSource() == cancelButton) {
			dispose();
		}

    }
}
