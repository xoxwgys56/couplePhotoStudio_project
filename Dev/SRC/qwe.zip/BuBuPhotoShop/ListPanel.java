package BuBuPhotoShop;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ListPanel extends JPanel {
	private JTextField searchTextField;
	private JTextField customerNameField;
	private JTextField cutomerPhoneNumField;
	private JTextField photoTypeField;
	private JLabel photoType;
	private JTextField customerNumField;
	private JTextField numOfPeopleField;
	private JTextField creationDateField;
	private JTextField reservationDateField;
	private JTextField lastDateField;
	private DefaultTableModel model;
	private JTable table;

	public ListPanel() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[] { 458, 0 };
		gridBagLayout.rowHeights = new int[] { 20, 483, 0 };
		gridBagLayout.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gridBagLayout.rowWeights = new double[] { 0.0, 1.0, Double.MIN_VALUE };
		setLayout(gridBagLayout);

		JPanel topPanel = new JPanel();
		GridBagConstraints gbc_topPanel = new GridBagConstraints();
		gbc_topPanel.anchor = GridBagConstraints.NORTH;
		gbc_topPanel.fill = GridBagConstraints.HORIZONTAL;
		gbc_topPanel.insets = new Insets(0, 0, 5, 0);
		gbc_topPanel.gridx = 0;
		gbc_topPanel.gridy = 0;
		add(topPanel, gbc_topPanel);
		GridBagLayout gbl_topPanel = new GridBagLayout();
		gbl_topPanel.columnWidths = new int[] { 456, 0 };
		gbl_topPanel.rowHeights = new int[] { 23, 93, 0 };
		gbl_topPanel.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
		gbl_topPanel.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
		topPanel.setLayout(gbl_topPanel);

		JPanel serchPanel = new JPanel();
		GridBagConstraints gbc_serchPanel = new GridBagConstraints();
		gbc_serchPanel.anchor = GridBagConstraints.NORTH;
		gbc_serchPanel.fill = GridBagConstraints.HORIZONTAL;
		gbc_serchPanel.insets = new Insets(0, 0, 5, 0);
		gbc_serchPanel.gridx = 0;
		gbc_serchPanel.gridy = 0;
		topPanel.add(serchPanel, gbc_serchPanel);
		GridBagLayout gbl_serchPanel = new GridBagLayout();
		gbl_serchPanel.columnWidths = new int[] { 84, 74, 116, 108, 74, 0 };
		gbl_serchPanel.rowHeights = new int[] { 23, 0 };
		gbl_serchPanel.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_serchPanel.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
		serchPanel.setLayout(gbl_serchPanel);

		JComboBox howtoSearch = new JComboBox();
		GridBagConstraints gbc_howtoSearch = new GridBagConstraints();
		gbc_howtoSearch.anchor = GridBagConstraints.WEST;
		gbc_howtoSearch.insets = new Insets(0, 0, 0, 5);
		gbc_howtoSearch.gridx = 0;
		gbc_howtoSearch.gridy = 0;
		serchPanel.add(howtoSearch, gbc_howtoSearch);
		howtoSearch.setModel(new DefaultComboBoxModel(new String[] { "�̸�", "���೯¥" }));

		searchTextField = new JTextField();
		GridBagConstraints gbc_searchTextField = new GridBagConstraints();
		gbc_searchTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_searchTextField.gridwidth = 3;
		gbc_searchTextField.insets = new Insets(0, 0, 0, 5);
		gbc_searchTextField.gridx = 1;
		gbc_searchTextField.gridy = 0;
		serchPanel.add(searchTextField, gbc_searchTextField);
		searchTextField.setColumns(10);

		JButton serchButton = new JButton("�˻�");
		GridBagConstraints gbc_serchButton = new GridBagConstraints();
		gbc_serchButton.fill = GridBagConstraints.HORIZONTAL;
		gbc_serchButton.anchor = GridBagConstraints.NORTH;
		gbc_serchButton.gridx = 4;
		gbc_serchButton.gridy = 0;
		serchPanel.add(serchButton, gbc_serchButton);

		Vector<String> head = new Vector<String>();
		head.addElement("������ȣ");
		head.addElement("�����̸�");
		head.addElement("���೯¥");
		model = new DefaultTableModel(head, 0);
		table = new JTable(model);
		table.setGridColor(Color.WHITE);
		JScrollPane listScrollPane = new JScrollPane(table);
		GridBagConstraints gbc_listScrollPane = new GridBagConstraints();
		gbc_listScrollPane.fill = GridBagConstraints.BOTH;
		gbc_listScrollPane.gridx = 0;
		gbc_listScrollPane.gridy = 1;
		topPanel.add(listScrollPane, gbc_listScrollPane);


		JPanel infoPanel = new JPanel();
		GridBagConstraints gbc_infoPanel = new GridBagConstraints();
		gbc_infoPanel.fill = GridBagConstraints.BOTH;
		gbc_infoPanel.gridx = 0;
		gbc_infoPanel.gridy = 1;
		add(infoPanel, gbc_infoPanel);
		GridBagLayout gbl_infoPanel = new GridBagLayout();
		gbl_infoPanel.columnWidths = new int[] { 104, 114, 115, 87, 0 };
		gbl_infoPanel.rowHeights = new int[] { 0, 21, 21, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_infoPanel.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_infoPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
				1.0, 1.0, Double.MIN_VALUE };
		infoPanel.setLayout(gbl_infoPanel);

		JLabel customerNum = new JLabel("������ȣ");
		GridBagConstraints gbc_customerNum = new GridBagConstraints();
		gbc_customerNum.anchor = GridBagConstraints.WEST;
		gbc_customerNum.insets = new Insets(0, 0, 5, 5);
		gbc_customerNum.gridx = 0;
		gbc_customerNum.gridy = 0;
		infoPanel.add(customerNum, gbc_customerNum);

		customerNumField = new JTextField();
		GridBagConstraints gbc_customerNumField = new GridBagConstraints();
		gbc_customerNumField.insets = new Insets(0, 0, 5, 5);
		gbc_customerNumField.fill = GridBagConstraints.HORIZONTAL;
		gbc_customerNumField.gridx = 1;
		gbc_customerNumField.gridy = 0;
		infoPanel.add(customerNumField, gbc_customerNumField);
		customerNumField.setColumns(10);

		JLabel numOfPeople = new JLabel("�ο���");
		GridBagConstraints gbc_numOfPeople = new GridBagConstraints();
		gbc_numOfPeople.anchor = GridBagConstraints.WEST;
		gbc_numOfPeople.insets = new Insets(0, 0, 5, 5);
		gbc_numOfPeople.gridx = 2;
		gbc_numOfPeople.gridy = 0;
		infoPanel.add(numOfPeople, gbc_numOfPeople);

		numOfPeopleField = new JTextField();
		GridBagConstraints gbc_numOfPeopleField = new GridBagConstraints();
		gbc_numOfPeopleField.insets = new Insets(0, 0, 5, 0);
		gbc_numOfPeopleField.fill = GridBagConstraints.HORIZONTAL;
		gbc_numOfPeopleField.gridx = 3;
		gbc_numOfPeopleField.gridy = 0;
		infoPanel.add(numOfPeopleField, gbc_numOfPeopleField);
		numOfPeopleField.setColumns(10);

		JLabel customerName = new JLabel("�����̸�");
		GridBagConstraints gbc_customerName = new GridBagConstraints();
		gbc_customerName.anchor = GridBagConstraints.WEST;
		gbc_customerName.fill = GridBagConstraints.VERTICAL;
		gbc_customerName.insets = new Insets(0, 0, 5, 5);
		gbc_customerName.gridx = 0;
		gbc_customerName.gridy = 1;
		infoPanel.add(customerName, gbc_customerName);

		customerNameField = new JTextField();
		GridBagConstraints gbc_customerNameField = new GridBagConstraints();
		gbc_customerNameField.fill = GridBagConstraints.HORIZONTAL;
		gbc_customerNameField.gridwidth = 3;
		gbc_customerNameField.insets = new Insets(0, 0, 5, 0);
		gbc_customerNameField.gridx = 1;
		gbc_customerNameField.gridy = 1;
		infoPanel.add(customerNameField, gbc_customerNameField);
		customerNameField.setColumns(10);

		JLabel cutomerPhoneNum = new JLabel("��ȭ��ȣ");
		GridBagConstraints gbc_cutomerPhoneNum = new GridBagConstraints();
		gbc_cutomerPhoneNum.anchor = GridBagConstraints.WEST;
		gbc_cutomerPhoneNum.fill = GridBagConstraints.VERTICAL;
		gbc_cutomerPhoneNum.insets = new Insets(0, 0, 5, 5);
		gbc_cutomerPhoneNum.gridx = 0;
		gbc_cutomerPhoneNum.gridy = 2;
		infoPanel.add(cutomerPhoneNum, gbc_cutomerPhoneNum);

		cutomerPhoneNumField = new JTextField();
		GridBagConstraints gbc_cutomerPhoneNumField = new GridBagConstraints();
		gbc_cutomerPhoneNumField.fill = GridBagConstraints.HORIZONTAL;
		gbc_cutomerPhoneNumField.gridwidth = 3;
		gbc_cutomerPhoneNumField.insets = new Insets(0, 0, 5, 0);
		gbc_cutomerPhoneNumField.gridx = 1;
		gbc_cutomerPhoneNumField.gridy = 2;
		infoPanel.add(cutomerPhoneNumField, gbc_cutomerPhoneNumField);
		cutomerPhoneNumField.setColumns(10);

		photoType = new JLabel("�Կ�����");
		GridBagConstraints gbc_photoType = new GridBagConstraints();
		gbc_photoType.anchor = GridBagConstraints.WEST;
		gbc_photoType.fill = GridBagConstraints.VERTICAL;
		gbc_photoType.insets = new Insets(0, 0, 5, 5);
		gbc_photoType.gridx = 0;
		gbc_photoType.gridy = 3;
		infoPanel.add(photoType, gbc_photoType);

		photoTypeField = new JTextField();
		GridBagConstraints gbc_photoTypeField = new GridBagConstraints();
		gbc_photoTypeField.insets = new Insets(0, 0, 5, 0);
		gbc_photoTypeField.fill = GridBagConstraints.HORIZONTAL;
		gbc_photoTypeField.gridwidth = 3;
		gbc_photoTypeField.gridx = 1;
		gbc_photoTypeField.gridy = 3;
		infoPanel.add(photoTypeField, gbc_photoTypeField);
		photoTypeField.setColumns(10);

		JLabel creationDate = new JLabel("������¥");
		GridBagConstraints gbc_creationDate = new GridBagConstraints();
		gbc_creationDate.anchor = GridBagConstraints.WEST;
		gbc_creationDate.insets = new Insets(0, 0, 5, 5);
		gbc_creationDate.gridx = 0;
		gbc_creationDate.gridy = 4;
		infoPanel.add(creationDate, gbc_creationDate);

		creationDateField = new JTextField();
		GridBagConstraints gbc_creationDateField = new GridBagConstraints();
		gbc_creationDateField.gridwidth = 3;
		gbc_creationDateField.insets = new Insets(0, 0, 5, 0);
		gbc_creationDateField.fill = GridBagConstraints.HORIZONTAL;
		gbc_creationDateField.gridx = 1;
		gbc_creationDateField.gridy = 4;
		infoPanel.add(creationDateField, gbc_creationDateField);
		creationDateField.setColumns(10);

		JLabel reservationDate = new JLabel("���೯¥");
		GridBagConstraints gbc_reservationDate = new GridBagConstraints();
		gbc_reservationDate.anchor = GridBagConstraints.WEST;
		gbc_reservationDate.insets = new Insets(0, 0, 5, 5);
		gbc_reservationDate.gridx = 0;
		gbc_reservationDate.gridy = 5;
		infoPanel.add(reservationDate, gbc_reservationDate);

		reservationDateField = new JTextField();
		GridBagConstraints gbc_reservationDateField = new GridBagConstraints();
		gbc_reservationDateField.gridwidth = 3;
		gbc_reservationDateField.insets = new Insets(0, 0, 5, 0);
		gbc_reservationDateField.fill = GridBagConstraints.HORIZONTAL;
		gbc_reservationDateField.gridx = 1;
		gbc_reservationDateField.gridy = 5;
		infoPanel.add(reservationDateField, gbc_reservationDateField);
		reservationDateField.setColumns(10);

		JLabel lastDate = new JLabel("������¥");
		GridBagConstraints gbc_lastDate = new GridBagConstraints();
		gbc_lastDate.anchor = GridBagConstraints.WEST;
		gbc_lastDate.insets = new Insets(0, 0, 5, 5);
		gbc_lastDate.gridx = 0;
		gbc_lastDate.gridy = 6;
		infoPanel.add(lastDate, gbc_lastDate);

		lastDateField = new JTextField();
		GridBagConstraints gbc_lastDateField = new GridBagConstraints();
		gbc_lastDateField.gridwidth = 3;
		gbc_lastDateField.insets = new Insets(0, 0, 5, 0);
		gbc_lastDateField.fill = GridBagConstraints.HORIZONTAL;
		gbc_lastDateField.gridx = 1;
		gbc_lastDateField.gridy = 6;
		infoPanel.add(lastDateField, gbc_lastDateField);
		lastDateField.setColumns(10);

		JLabel calibrationInfo = new JLabel("��������");
		GridBagConstraints gbc_calibrationInfo = new GridBagConstraints();
		gbc_calibrationInfo.anchor = GridBagConstraints.WEST;
		gbc_calibrationInfo.insets = new Insets(0, 0, 5, 5);
		gbc_calibrationInfo.gridx = 0;
		gbc_calibrationInfo.gridy = 7;
		infoPanel.add(calibrationInfo, gbc_calibrationInfo);

		JLabel charge = new JLabel("��ݳ��ο���");
		GridBagConstraints gbc_charge = new GridBagConstraints();
		gbc_charge.anchor = GridBagConstraints.WEST;
		gbc_charge.insets = new Insets(0, 0, 5, 5);
		gbc_charge.gridx = 2;
		gbc_charge.gridy = 7;
		infoPanel.add(charge, gbc_charge);

		JCheckBox chargeCheck = new JCheckBox("");
		GridBagConstraints gbc_chargeCheck = new GridBagConstraints();
		gbc_chargeCheck.insets = new Insets(0, 0, 5, 0);
		gbc_chargeCheck.gridx = 3;
		gbc_chargeCheck.gridy = 7;
		infoPanel.add(chargeCheck, gbc_chargeCheck);

		JScrollPane calibrationInfoScrollPane = new JScrollPane();
		GridBagConstraints gbc_calibrationInfoScrollPane = new GridBagConstraints();
		gbc_calibrationInfoScrollPane.gridwidth = 4;
		gbc_calibrationInfoScrollPane.gridheight = 8;
		gbc_calibrationInfoScrollPane.fill = GridBagConstraints.BOTH;
		gbc_calibrationInfoScrollPane.gridx = 0;
		gbc_calibrationInfoScrollPane.gridy = 8;
		infoPanel.add(calibrationInfoScrollPane, gbc_calibrationInfoScrollPane);

		JTextArea calibrationInfoTextArea = new JTextArea();
		calibrationInfoScrollPane.setViewportView(calibrationInfoTextArea);


	}

	public void setList(CustomerInfo[] ci) {
		for (int i = 0; i < ci.length; i++) {
			Vector<String> rowvec = new Vector<String>();
			rowvec.addElement(String.valueOf(ci[i].num));
			rowvec.addElement(ci[i].name);
			rowvec.addElement(ci[i].reservationDate);
			model.addRow(rowvec);
		}
		/*
		 * Vector numvec=new Vector(); Vector<String> namevec=new Vector();
		 * Vector<String> datevec=new Vector(); for(int i=0;i<ci.length;i++) {
		 * numvec.addElement(ci[i].num); namevec.addElement(ci[i].name);
		 * datevec.addElement(ci[i].reservationDate); } numList.setListData(numvec);
		 * nameList.setListData(namevec); dateList.setListData(datevec);
		 * numList.setSelectedIndex(0); nameList.setSelectedIndex(0);
		 * dateList.setSelectedIndex(0);
		 */

	}
}
