package BuBuPhotoShop;

import java.sql.SQLException;

import javax.swing.JFrame;

public class testFrame extends JFrame{
	ListPanel listpan;
	private static CustomerInfo[] ci;
	public testFrame() {
		setSize(500,800);
		listpan=new ListPanel();
		add(listpan);
		setVisible(true);
	}
	public static void main(String[] args) {
		testFrame as=new testFrame();
		ci =new CustomerInfo[50];
		DB_insert dbi =new DB_insert();
		try {
			dbi.getRecord(ci);
		}
		catch(SQLException se) {
			
		}
		as.listpan.setList(ci);
	}
}

