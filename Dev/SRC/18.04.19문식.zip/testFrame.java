package BuBuPhotoshop;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;

public class testFrame extends JFrame{
	ListPanel listpan;
	ButtonPanel btnpan;
	static Vector<CustomerInfo> c_vec;
	public testFrame() {
		c_vec=new Vector(1);
		setSize(1000,800);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{294, 436, 84, 0};
		gridBagLayout.rowHeights = new int[]{472, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		listpan=new ListPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 0;
		getContentPane().add(listpan, gbc_panel);
		
		btnpan=new ButtonPanel(c_vec,listpan);
		gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 3;
		gbc_panel.gridy = 0;
		getContentPane().add(btnpan, gbc_panel);
		
		setVisible(true);
		
		/*ci =new CustomerInfo[3];
		for ( int i = 0; i < ci.length ; i++) {
			ci[i] = new CustomerInfo();
		}*/
		
		DB_insert dbi =new DB_insert();
		try {
			dbi.getRecord(c_vec);
		}
		catch(SQLException se) {
			
		}
		listpan.setList(c_vec);
	}
	public static void main(String[] args) {
		testFrame as=new testFrame();
	}
	
	
}

