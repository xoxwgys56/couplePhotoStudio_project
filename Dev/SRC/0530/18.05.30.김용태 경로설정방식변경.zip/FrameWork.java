package framework;

import java.io.File;

import database.DB_insert;
import util.FileLoader;
import util.Handling;

/*
 * Loop�� �̿��� Framework �̹��� ���
 * 
 * */

public class FrameWork {

	private Display display;
	
	private FileLoader fileLoader;
	private readpath read;
	private String path = read.read1();   //db���� framework�� ���� 18.05.30
	
	private Handling handling;
	
	public FrameWork(Handling handling) {
		this.handling = handling;
		init();
	}
	
	private void init() {
		display = handling.getDisplay();
		fileLoader = new FileLoader(path);
		fileLoad("NULL");
	}
	
	public void fileLoad(String path) {
		// ó���� ���
	//	if ( path.equals("NULL"))
		fileLoader.LoadFiles(new File(display.getPath()));
	//	else 
	//		fileLoader.LoadFiles(new File(path));
		
		display.clean_render();
		display.render(fileLoader.getIcon(), fileLoader.getFilePath(), 
						fileLoader.getFileName(), fileLoader.getFileCount());
	}
	
	
	public Display getDisplay() {
		return this.display;
	}
	
}