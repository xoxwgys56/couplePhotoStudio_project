package util;

import java.awt.Image;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class FileLoader {

	private String path;
	private String[] fileName;
	private String[] filePath;
	public String[] getFileName() {
		return fileName;
	}

	public String[] getFilePath() {
		return filePath;
	}

	private ImageIcon[] icon;
	
	private int size = 100;
	private File folder;
	private int fileCount;
	
	private ImageIcon folderImage;
	private ImageIcon rawImage;

	public FileLoader(String path) {
		icon = new ImageIcon[size];
		fileName = new String[size];
		filePath = new String[size];
		this.path = path;

		//�̹��� ũ�� ����
		ImageIcon originIcon = new ImageIcon("res/folder.png");  
		Image originImg = originIcon.getImage(); 
		Image changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		folderImage = new ImageIcon(changedImg);
		
		originIcon = new ImageIcon("res/raw.png");  
		originImg = originIcon.getImage(); 
		changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
		rawImage = new ImageIcon(changedImg);
	}

	public void LoadFiles(File folder) {
		
		if (!folder.exists())
			return;
		icon = new ImageIcon[size];

		int i = 0;
		this.path = folder.getAbsolutePath();
		
		fileCount = 0;
		for (File fileEntry : folder.listFiles()) {
			this.fileCount++;
			if (fileEntry.isDirectory()) {
				filePath[i] = fileEntry.getAbsolutePath();
				fileName[i] = fileEntry.getName();
				icon[i++] = folderImage;
				
			} else {
				fileName[i] = fileEntry.getName();
				filePath[i] = fileEntry.getAbsolutePath();
				// Ȯ���� �˻�
				int pos = fileName[i].lastIndexOf('.');
				// ����Ȯ���ڰ� raw Ȥ�� RAW���
				switch( fileName[i].substring(pos+1) ) {
				case "raw" :
				case "RAW" :
				/** Nikon */
				case "NEF" :
				case "nef" :
				case "nrw" :
				case "NRW" :
				/** Cannon */
				case "crw" :
				case "CRW" :
				case "cr2" :
				case "CR2" :
				case "cr3" :
				case "CR3" :
				/** Sony */
				case "arw" :
				case "ARW" :
				/** Fuji film*/
				case "raf" :
				case "RAF" :
						icon[i++] = rawImage;
					break;
				// ���� ���ϸ� ǥ�õǰ�
				case "jpg" :
				case "bmp" :
				case "gif" :
				case "png" : 
					Image originImg = new ImageIcon(filePath[i]).getImage();  
					Image changedImg= originImg.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
					icon[i++] = new ImageIcon(changedImg);
					break;
				default :
					fileCount--;
					break;
				}
			}
		}
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public ImageIcon[] getIcon() {
		return icon;
	}
	
	public File getFolder() {
		return this.folder;
	}
	
	public int getFileCount() {
		return fileCount;
	}

}