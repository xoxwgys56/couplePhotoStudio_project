package framework;

import java.util.Date;

public class CustomerInfo {
	String name;
	String phoneNum;
	String photoType;
	int num;
	int numOfPeople=1;
	String creationDate;
	String reservationDate;
	String lastDate;
	String calibrationInfo;
	int charge;
	
	public CustomerInfo(int c_num,String c_name, String c_phone, String c_kindofshut, int c_howmany, String createdate, String c_date, String finaldate, int pay, String bigo) {
		name=c_name;
		phoneNum=c_phone;
		photoType=c_kindofshut;
		numOfPeople=c_howmany;
		creationDate=createdate;
		reservationDate=c_date;
		lastDate=finaldate;
		num=c_num;
		calibrationInfo=bigo;
		charge=pay;
		System.out.println(name);
	}
	public int getnum() {
		return num;
	}
}
