package test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;

/*
 * Loop�� �̿��� Framework �̹��� ���
 * 
 * */

public class FrameWork implements Runnable{

	public FrameWork() {
		
	}

	private Display display;
	private int width, height;
	
	private boolean running = false;
	private Thread thread;
	
	private BufferStrategy bs;
	private Graphics g;

	private FileLoader fileLoader;
	private String path = "J:/testImg";
	private BufferedImage[] imageList;
	private int offset;
	private int imgWidth, imgHeight;
	
	private void init(){
		this.offset=130;
		this.imgWidth=100; this.imgHeight=100;
		
		display = new Display(path);
		width = display.getWidth();
		height = display.getHeight();
		fileLoader = new FileLoader(path);
		fileLoader();
	}
	
	private void fileLoader() {
		fileLoader.LoadFiles();
		imageList = new BufferedImage[100];
		imageList = fileLoader.getImageList();
	}
	
	private void tick(){
		fileLoader.setPath(display.getPath());
		fileLoader.LoadFiles();
		imageList = fileLoader.getImageList();
	}
	
	private void render(){
		
		bs = display.getCanvas().getBufferStrategy();
		if(bs == null){
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		g = bs.getDrawGraphics();
		//Clear Screen
		g.clearRect(0, 0, 512, 512);
		//Draw Here!
		//g.drawImage(imageList[], 0, 0, 300, 300, null);
		int x=0, y=0;
		
		for (BufferedImage img : imageList) {
			char[] str = {'t', 'e', 's', 't'};
			
			g.drawImage(img, 10+(x)*offset, y, imgWidth, imgHeight, null);
			//g.setColor(new Color(0,255,0));
			g.drawChars(str, 0, str.length, 10+(x++)*offset, 12+y+imgHeight);
			System.out.println(x +", "+y);
			if (x > 4) {
				y += offset;
				x = 0;
			}
			//if (y >= offset)
		}
		
		//End Drawing!
		bs.show();
		g.dispose();
	}
	
	@Override
	public void run(){
		init();
		
		int fps = 60;
		double timePerTick = 1000000000 / fps;
		double delta = 0;
		long now;
		long lastTime = System.nanoTime();
		long timer = 0;
		int ticks = 0;
		
		while(running){
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime;
			lastTime = now;
			
			if(delta >= 1){
				tick();
				render();
				ticks++;
				delta--;
			}
			
			if(timer >= 1000000000){
				//System.out.println("Ticks and Frames: " + ticks);
				ticks = 0;
				timer = 0;
			}
		}
		
		stop();
		
	}
	
	public synchronized void start(){
		if(running)
			return;
		running = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public synchronized void stop(){
		if(!running)
			return;
		running = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
