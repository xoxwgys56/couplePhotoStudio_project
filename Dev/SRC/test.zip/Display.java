package test;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*
 * setPath�� ����, path ������Ʈ�� �ʿ��ϴ�.
 * */

public class Display extends JFrame{

	private JPanel panel;
	private Canvas canvas;
	private JTextField field;
	
	public static String path;
	private int width, height;
	
	//
	ListPanel listpan;
	ButtonPanel btnpan;
	static Vector<CustomerInfo> c_vec;
	private GridBagConstraints gbc_panel_1;

	Dimension res = Toolkit.getDefaultToolkit().getScreenSize();
	public Display() {
		this.width = res.width;
		this.height = res.height;
		path = "C:/";
		init();
		//default path
		
	}
	
	public Display(String path) {
		this.width = res.width;
		this.height = res.height;
		this.path = path;
		
		init();
	}
	
	public void init() {
		this.setTitle("title");
		//this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		GridBagConstraints gbc_panel = new GridBagConstraints();
		c_vec=new Vector(1);
		setSize(1000,800);
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{294, 436, 84, 0};
		gridBagLayout.rowHeights = new int[]{472, 0};
		gridBagLayout.columnWeights = new double[]{0.0, 1.0, 1.0, 0.0};
		gridBagLayout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		listpan=new ListPanel();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 0;
		getContentPane().add(listpan, gbc_panel);
		
		btnpan=new ButtonPanel(c_vec,listpan);
		gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 0, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 3;
		gbc_panel.gridy = 0;
		getContentPane().add(btnpan, gbc_panel);
		
		panel = new JPanel();
		gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 2;
		gbc_panel_1.insets = new Insets(0, 0, 0, 5);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 0;
		getContentPane().add(panel, gbc_panel_1);
		canvas = new Canvas();
		field = new JTextField();
		
		panel.setSize(512, 512);
		panel.setBorder(BorderFactory.createLineBorder(Color.black));
		panel.setLayout(new BorderLayout());
		
		field.setSize(100, 100);
		field.setText(path);
		field.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				path = field.getText();
				System.out.println(path);
			}
		});
		
		//canvas.setSize(512, 512);
		
		//this.add(panel);
		panel.add(canvas, "Center");
		panel.add(field, "North");
		
		//this.pack();
		
		//this.setVisible(true);
		
		setVisible(true);
		
		/*ci =new CustomerInfo[3];
		for ( int i = 0; i < ci.length ; i++) {
			ci[i] = new CustomerInfo();
		}*/
		
		DB_insert dbi =new DB_insert();
		try {
			dbi.getRecord(c_vec);
		}
		catch(SQLException se) {
			System.out.println(se);
		}
		listpan.setList(c_vec);
	}
	
	public JPanel getPanel() {
		return panel;
	}

	public Canvas getCanvas() {
		return canvas;
	}

	public JTextField getField() {
		return field;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getPath() {
		return path;
	}

	public void setCanvasSize() {
		canvas.setSize(panel.getWidth(), panel.getHeight());
	}

}
