package test;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * JTable�� ���� �̹��� ���
 * 
 * */

public class ImageTablePanel extends JPanel{

	// table.setRowHeight(1, 300);//***cell height setting

	private String[] columnNames = {"Picture", "Description", "sdf", "asdf"};
    private Object[][] data;
    /*=
    {
        {1, 1},
        {1, "Add"},
        {1, "Copy"},
    };
*/
    private FileLoader fileLoader;
    
    private Icon[] icon;
    DefaultTableModel model;
    JTable table;
    
	public ImageTablePanel() {
		init();
	}
	
	private void init() {
		data = new Object[10][2];
		
		model = new DefaultTableModel(data, columnNames);
		table = new JTable( model );
		
		
	}
	
	public void setList(ImageIcon[] icon, String[] name) {
		for(int i=0; i<10; i++) {
			for (int j=0; j<10; j++) {
				if (i%2==0) {
					data[i][j] = icon[j];//
				}else {
					data[i][j] = name[j];//
				}
			}	
		}
		
	}
}
