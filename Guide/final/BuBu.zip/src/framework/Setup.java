 package framework;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class Setup extends JFrame implements ActionListener{

      private JPanel expanel,setpanel;
      private JTextField textField,textField2,textField3;
      private JLabel label,label1,label2,label3;
      private JButton choice1, choice2, choice3;
      private String path1, path2, path3;
      private ReadPath read;
      
      public Setup() {
    	setSize(600,180);
        BoxLayout layout = new BoxLayout(getContentPane(),BoxLayout.Y_AXIS);
        setLayout(layout);
        
        expanel = new JPanel();
        
        label = new JLabel("ȯ�漳��");
        expanel.add(label);
        
        read = new ReadPath();
        //�⺻ ���� ��������
        path1 = read.read1();
        path2 = read.read2();
        path3 = read.read3();
   
     System.out.println("qqpqp "+path2);   
        
        setpanel = new JPanel();
        setpanel.setLayout(new GridLayout(3,4));
          
           label1 = new JLabel("�������� �⺻��κ���");
           textField = new JTextField(path1);
           choice1 = new JButton("����");
	       choice1.addActionListener(this);
	      
           setpanel.add(label1);
	       setpanel.add(textField);
	       setpanel.add(choice1);
	       
	       
	       label2 = new JLabel("���伥 ��μ���");   //���� 2018.05.25 kyt
           textField2 = new JTextField(path2);
           choice2 = new JButton("����");
	       choice2.addActionListener(this);
	       
	       setpanel.add(label2);
	       setpanel.add(textField2);
	       setpanel.add(choice2);
	       

	       label3 = new JLabel("����Ʈ�� ��μ���");
           textField3 = new JTextField(path3);
           choice3 = new JButton("����");
	       choice3.addActionListener(this);
	       
	       setpanel.add(label3);
	       setpanel.add(textField3);
	       setpanel.add(choice3);
	       
	       
        add(expanel);
        add(setpanel);
        setVisible(true);
        
    }
   
         
   @Override
   public void actionPerformed(ActionEvent e) {
	   
	   // �⺻���
      if(e.getSource() == choice1) {
    	 pathWrite(textField, "C:/testImg/basic.txt");
    	 
      }
      
      // ���伥 ���
      if(e.getSource() == choice2) {
     	 pathWrite(textField2,  "C:/testImg/photo.txt");
      }
      
      // ����Ʈ�� ���
      if(e.getSource() == choice3) {
     	 pathWrite(textField3, "C:/testImg/lightroom.txt");
      }
   }
   
   public void pathWrite(JTextField field, String base) {
	   JFileChooser jfc = new JFileChooser();
	   jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	   jfc.showDialog(this, null);
	   File dir = jfc.getSelectedFile();
	   System.out.println(dir.getPath());
	  
	   field.setText(dir.getAbsolutePath());
	   
	   File file = new File(base);
	   FileWriter writer = null;
		
		 try {
	            // ���� ������ ���뿡 �̾ ������ true��, ���� ������ ���ְ� ���� ������ false�� �����Ѵ�.
	            writer = new FileWriter(file, false);
	            writer.write(field.getText());
	            writer.flush(); 
	            System.out.println("DONE");
	          
	        } catch(IOException e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if(writer != null) writer.close();
	            } catch(IOException e) {
	                e.printStackTrace();
	            }
	        }
   }
}