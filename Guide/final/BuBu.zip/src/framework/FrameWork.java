package framework;

import java.io.File;
import java.sql.SQLException;

import database.DB_insert;
import util.FileLoader;
import util.Handling;
import javax.swing.JOptionPane;


/*
 * Loop�� �̿��� Framework �̹��� ���
 * 
 * */

public class FrameWork {

	private Display display;
	
	private FileLoader fileLoader;
	private ReadPath read;
	private String path;   //db���� framework�� ���� 18.05.30
	private Handling handling;
	
	public FrameWork(Handling handling) {
		this.handling = handling;
		init();
	}
	
	private void init() {
		 	
			display = handling.getDisplay();
			fileLoader = new FileLoader(path);
			fileLoad("NULL");
			read = new ReadPath();
			path = read.read1();
	}
	public void fileLoad(String path) {
		// ó���� ���
	//	if ( path.equals("NULL"))
		fileLoader.LoadFiles(new File(display.getPath()));
	//	else 
	//		fileLoader.LoadFiles(new File(path));
		
		display.clean_render();
		display.render(fileLoader.getIcon(), fileLoader.getFilePath(), 
						fileLoader.getFileName(), fileLoader.getFileCount());
	}
	
	
	public Display getDisplay() {
		return this.display;
	}
	
}