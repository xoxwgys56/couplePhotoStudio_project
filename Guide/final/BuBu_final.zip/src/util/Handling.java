package util;

import java.sql.SQLException;

import database.DB_insert;
import framework.Display;
import framework.ReadPath;

public class Handling {

	private static Display display;
	private String path;
	private DB_insert db;
	private ReadPath read;
	public Handling() {		
		read = new ReadPath();
		path = read.read1();
		display = new Display(path);
	
	}
	public static Display getDisplay() {
		return display;
	}
}