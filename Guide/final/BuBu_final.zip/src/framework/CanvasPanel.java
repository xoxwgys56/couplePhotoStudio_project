package framework;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class CanvasPanel extends JPanel {

	private Image image = null;
	public CanvasPanel() {
		//  ��� �̹���
		image = new ImageIcon("res/back.jpg").getImage();
	}
	
	 @Override
	 public void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        
	        // �г� ���� ���� �޾Ƽ� �׸�
	        if (image != null) {
	            int imgWidth, imgHeight;
	            imgWidth = this.getWidth();
	            imgHeight = this.getHeight();
	            g.drawImage(image, 0, 0, imgWidth, imgHeight, this);
	        }
	 }
}
